#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <limits>
#include <fstream> // Include for file handling
using namespace std;
// Structure to represent an item
struct Item {
    string name;
    int quantity;
    double price;
};
// Vector to store items
vector<Item> items;
// Function to load inventory from a file
void loadInventory(const string &filename) {
    ifstream file(filename);
    if (file.is_open()) {
        items.clear(); // Clear any existing items
        string name;
        int quantity;
        double price;
        while (file >> name >> quantity >> price) {
            items.push_back({name, quantity, price});
        }
        file.close();
    } else {
        cout << "\nCould not open file. Starting with an empty inventory." << endl;

        // Add example items if file doesn't exist
        items= {
            {"Apple", 50, 0.5},
            {"Banana", 100, 0.2},
            {"Milk", 30, 1.2},
            {"Bread", 20, 1.5},
            {"Eggs", 12, 0.1}
        };
        cout << "\nExample items added to inventory." << endl;
    }
}

// Function to save inventory to a file
void saveInventory(const string& filename) {
    ofstream file(filename);
    if (file.is_open()) {
    	//Range-Based For Loops
        for (const auto& item : items) {
            file << item.name << " " << item.quantity << " " << item.price << endl;
        }
        file.close();
    } else {
        cout << "\nCould not open file for saving inventory!" << endl;
    }
}

// Function to add an item
void addItem() {
    Item item;
    cout << "\n\t\tAdd Item" << endl;
    cout << "\t\t---------" << endl;
    cout << "Enter item name: ";
    cin >> item.name;

    while (true) {
        cout << "Enter item quantity: ";
        if (!(cin >> item.quantity) || item.quantity <= 0) {
            cout << "Invalid quantity! Please enter a positive integer." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        } else {
            break;
        }
    }

    while (true) {
        cout << "Enter item price: ";
        if (!(cin >> item.price) || item.price <= 0) {
            cout << "Invalid price! Please enter a positive number." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        } else {
            break;
        }
    }

    items.push_back(item);
    cout << "\nItem added successfully!" << endl;
}

// Function to remove an item
void removeItem() {
    string name;
    cout << "\n\t\tRemove Item" << endl;
    cout << "\t\t-----------" << endl;
    cout << "Enter item name to remove: ";
    cin >> name;

    auto it = find_if(items.begin(), items.end(), [&](const Item& item) { return item.name == name; });
    if (it != items.end()) {
        items.erase(it);
        cout << "\nItem removed successfully!" << endl;
    } else {
        cout << "\nItem not found!" << endl;
    }
}

// Function to generate bill and save to file
void generateBill() {
    if (items.empty()) {
        cout << "\nNo items available!" << endl;
        return;
    }

    // Ask for customer name
    string customerName;
    cout << "\nEnter customer name: ";
    cin.ignore(); // Clear the input buffer
    getline(cin, customerName);

    cout << "\n\t\tAvailable Items" << endl;
    cout << "\t\t----------------" << endl;
    for (int i = 0; i < items.size(); ++i) {
        cout << i + 1 << ". " << items[i].name << " - Quantity: " << items[i].quantity << " - Price: " << items[i].price << endl;
    }

    vector<pair<int, int>> purchases;
    while (true) {
        int choice;
        cout << "\nEnter the item number to purchase (0 to finish): ";
        cin >> choice;

        if (choice == 0) {
            break;
        }

        if (choice < 1 || choice > items.size()) {
            cout << "\nInvalid choice! Please enter a valid item number." << endl;
            continue;
        }

        int quantity;
        while (true) {
            cout << "Enter the quantity to purchase: ";
            if (!(cin >> quantity) || quantity <= 0) {
                cout << "Invalid quantity! Please enter a positive integer." << endl;
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            } else {
                break;
            }
        }

        if (quantity > items[choice - 1].quantity) {
            cout << "\nInsufficient quantity!" << endl;
            continue;
        }

        purchases.push_back(make_pair(choice - 1, quantity));
    }

    if (purchases.empty()) {
        cout << "\nNo items purchased!" << endl;
        return;
    }

    double total = 0;
    string billFilename = "bills.txt";
    ofstream billFile(billFilename, ios::app);
    if (!billFile.is_open()) {
        cout << "\nCould not open file to save bill!" << endl;
        return;
    }

    // Write customer name at the top of the bill
    billFile << "\n---- New Bill ----\n";
    billFile << "Customer Name: " << customerName << "\n";
    billFile << "-------------------\n";

    cout << "\n\t\tPurchases" << endl;
    cout << "\t\t---------" << endl;
    cout << "Customer Name: " << customerName << endl;

    for (const auto& purchase : purchases) {
        double cost = items[purchase.first].price * purchase.second;
        total += cost;
        items[purchase.first].quantity -= purchase.second;

        // Log to console
        cout << items[purchase.first].name << " x " << purchase.second << " = " << cost << endl;

        // Save to bill file
        billFile << items[purchase.first].name << " x " << purchase.second << " = " << cost << "\n";
    }

    // Apply tax and discount
    const double taxRate = 0.05;      // 5% tax
    const double discountRate = 0.10; // 10% discount for example
    double tax = total * taxRate;
    double discount = total * discountRate;
    double finalTotal = total + tax - discount;

    // Display and save tax and discount details
    cout << "\nSubtotal: " << total << endl;
    cout << "Tax (5%): " << tax << endl;
    cout << "Discount (10%): " << discount << endl;
    cout << "Total: " << finalTotal << endl;

    billFile << "Subtotal: " << total << "\n";
    billFile << "Tax (5%): " << tax << "\n";
    billFile << "Discount (10%): " << discount << "\n";
    billFile << "Total: " << finalTotal << "\n";
    billFile << "-------------------\n";
    billFile.close();

    cout << "\nBill saved to " << billFilename << "!" << endl;
}

// Function to display inventory
void displayInventory() {
    if (items.empty()) {
        cout << "\nNo items available!" << endl;
        return;
    }
    cout << "\n\t\tInventory" << endl;
    cout << "\t\t---------" << endl;
    for (const auto& item : items) {
        cout << item.name << ": " << item.quantity << " x " << item.price << endl;
    }
}

// Function to check password
bool checkPassword() {
    string password;
    cout << "\t\tWelcome to Supermarket Billing System" << endl;
    cout << "\t\t----------------------------------------" << endl;
    cout << "\n\tLogin" << endl;
    cout << "\t\t-----" << endl;
    cout << "Enter password: ";
    cin >> password;
    if (password == "admin") {
        return true;
    }
    return false;
}

int main() {

    const string filename = "inventory.txt";

    // Load inventory from file
    loadInventory(filename);

    // Check password
    if (!checkPassword()) {
        cout << "\nInvalid password!" << endl;
        return 1;
    }
    // Main menu
    while (true) {
        cout << "\n\t\tMain Menu" << endl;
        cout << "\t\t---------" << endl;
        cout << "1. Add item" << endl;
        cout << "2. Remove item" << endl;
        cout << "3. Generate bill" << endl;
        cout << "4. Display inventory" << endl;
        cout << "5. Save and Exit" << endl;

        int choice;
        cout << "Enter your choice: ";
        while (!(cin >> choice) || choice < 1 || choice > 5) {
            cout << "\nInvalid choice! Please enter a number between 1 and 5." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Enter your choice: ";
        }

        switch (choice) {
            case 1:
                addItem();
                break;
            case 2:
                removeItem();
                break;
            case 3:
                generateBill();
                break;
            case 4:
                displayInventory();
                break;
            case 5:
                saveInventory(filename);
                cout << "\nExiting... Inventory saved. Goodbye!" << endl;
                return 0;
            default:
                break;
        }
    }
    return 0;
}
